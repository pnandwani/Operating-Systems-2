#include "types.h"
#include "user.h"

#define P_LOOP_CNT 0x10000000
#define C_LOOP_CNT 0x20000000


unsigned int avoid_optm = 0; // a variable used to avoid compiler optimization
void do_parent(void)
{
    unsigned int cnt = 0;
    unsigned int tmp = 0;

    while(cnt < P_LOOP_CNT)
    {
        tmp += cnt;
        cnt ++;
    }
    
    avoid_optm = tmp;
}


void do_child(void)
{
    unsigned int cnt = 0;
    unsigned int tmp = 0;

    while(cnt < C_LOOP_CNT)
    {
        tmp += cnt;
        cnt ++;
    }
    
    avoid_optm = tmp;
}

void example_test_code()
{
    int pid = 0;

    pid = fork();
    if (pid < 0)
    {
        printf(1, "fork() failed!\n");
        exit();
    }
    else if (pid == 0) // child
    {
        //printf(1, "child, its pid is %d and it has %d tickets\n",getpid(),tickets_owned(getpid()));
        //sleep(100);
        do_child();
    }
    else // parent
    {
        //printf(1, "parent, its pid is %d and it has %d tickets\n",getpid(),tickets_owned(getpid()));
        int tt = transfer_tickets(pid,49);
        printf(1, "Tickets Trasferred is %d\n",tt);
        printf(1, "parent, its pid is %d and it has %d tickets\n",getpid(),tickets_owned(getpid()));
        printf(1, "child, its pid is %d and it has %d tickets\n",pid,tickets_owned(pid));
        do_parent();
        if (wait() < 0)
        {
            printf(1, "wait() failed!\n");
        }
    }
}

void example_test_code1()
{
    int pid,pid1,pid2 = 0;

    pid = fork();
    if (pid < 0)
    {
        printf(1, "fork() failed!\n");
        exit();
    }
    else if (pid == 0) // child
    {
        printf(1, "child 1 its pid is %d and it has %d tickets \n",getpid(),tickets_owned(getpid()));
        //sleep(100);
        do_child();
    }
    else 
    {
        pid1 = fork(); 
        if (pid1 == 0) { 
            printf(1, "child 2 its pid is %d and it has %d tickets \n",getpid(),tickets_owned(getpid()));
            do_child();
        } 
        else { 
            pid2 = fork(); 
            if (pid2 == 0) { 
                // This is third child which is 
                // needed to be printed first. 
                printf(1, "child 3 its pid is %d and it has %d tickets \n",getpid(),tickets_owned(getpid()));
                do_child();
            } 
  
            // If value returned from fork() 
            // in not zero and >0 that means 
            // this is parent process. 
            else { 
                // This is asked to be printed at last 
                // hence made to sleep for 3 seconds. 
                printf(1, "parent its pid is %d and it has %d tickets \n",getpid(),tickets_owned(getpid()));
                do_parent();
                if (wait() < 0)
                {
                    printf(1, "wait() failed!\n");
                }
            } 
        } 
    }
	
	printf(1, "\n");
}

int
main(int argc, char *argv[])
{
    enable_sched_trace(1);
    set_sched(1);
    example_test_code();
    enable_sched_trace(0);
    
    exit();
}