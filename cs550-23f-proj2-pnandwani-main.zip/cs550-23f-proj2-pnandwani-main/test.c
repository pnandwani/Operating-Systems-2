#include "types.h"
#include "stat.h"
#include "user.h"

void testprogram()
{
    int parent_pid = getpid();
    printf(1, "parent: %d\n", tickets_owned(parent_pid));
    int rc = fork();
    if(rc == 0) 
    {
        int pid = getpid();
        int s = 10;
        printf(1, "child: %d\n",tickets_owned(pid));
        printf(1, "tickets tranferred: %d\n", transfer_tickets(parent_pid, -10));
        printf(1, "tickets tranferred: %d\n", transfer_tickets(parent_pid, 50));
        printf(1, "tickets tranferred: %d\n", transfer_tickets(897654, s));
        printf(1, "tickets tranferred: %d\n", transfer_tickets(parent_pid, s));
        printf(1, "parent: %d\n", tickets_owned(parent_pid));
        printf(1, "child: %d\n",tickets_owned(pid));
        exit();
    }
    else if(rc > 0) 
    {
        wait();
    }
    else
    {
        printf(1, "Fork failed\n");
    }
}

int main(int argc, char *argv[])
{
      set_sched(1);
      testprogram();  
      set_sched(0);
      exit(); 
}